create unique index PRIMARY_KEY_6
    on "flyway_schema_history" ("installed_rank");

