create unique index PRIMARY_KEY_26
    on CLUBS (SHORT_NAME);

